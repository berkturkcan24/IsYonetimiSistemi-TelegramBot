using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using IsYonetimiSistemi.Shared.Data;
using IsYonetimiSistemi.Shared.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace IsYonetimiSistemi.TelegramBot.Commands;

public class IslemCommands
{
    private readonly ILogger<IslemCommands> _logger;
    private readonly AppDbContext _context;

    public IslemCommands(ILogger<IslemCommands> logger, AppDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    // Bu s�n�f gelecekte gerekirse i�lem g�r�nt�leme komutlar� i�in kullan�labilir
    // �u anda t�m i�lem ekleme �zellikleri kald�r�lm��t�r - sadece masa�st� uygulamadan eklenebilir
}


