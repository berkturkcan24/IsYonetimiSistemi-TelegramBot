# Chat ID Bulma Rehberi

## Y�ntem 1: Uygulama Loglar�ndan
1. Uygulamay� durdurun (Ctrl+C)
2. Uygulamay� tekrar ba�lat�n: `dotnet run`
3. Telegram'dan botunuza `/start` yaz�n
4. Console'da �u sat�r� aray�n:
```
Message: /start from XXXXXXXX
```
veya
```
?? Yetkisiz eri�im denemesi - Chat ID: XXXXXXXX
```

## Y�ntem 2: Bot API ile
1. Telegram'dan botunuza herhangi bir mesaj g�nderin
2. Taray�c�da �u URL'ye gidin:
```
https://api.telegram.org/bot<BOT_TOKEN>/getUpdates
```
3. JSON response'da `"from": {"id": 123456789}` alan�n� bulun

## Y�ntem 3: @userinfobot kullan�n
1. Telegram'da @userinfobot botunu bulun
2. Bota `/start` yaz�n
3. Size Chat ID'nizi g�sterecek

## Chat ID'yi appsettings.json'a Ekleyin
```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "S�Z�N_CHAT_ID,5987654321,1234567890"
  }
}
```

**�NEML�:** Virg�lle ay�r�n, bo�luk yok!
