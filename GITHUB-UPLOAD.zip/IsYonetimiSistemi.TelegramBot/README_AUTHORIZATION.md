# ?? Telegram Bot Chat ID Yetkilendirme Sistemi

## ? Yap�lan De�i�iklikler

Telegram botunuza **Chat ID bazl� yetkilendirme sistemi** ba�ar�yla eklendi!

---

## ?? Eklenen Dosyalar

### 1. **AuthorizationService.cs**
- `Services/AuthorizationService.cs`
- Chat ID kontrol� yapar
- Yetkisiz eri�imleri loglar
- Yap�land�rma dosyas�ndan yetkili kullan�c�lar� okur

### 2. **BotUpdateHandler.cs** (G�ncellendi)
- Her mesaj ve callback'te yetki kontrol� yapar
- Yetkisiz kullan�c�lara uyar� mesaj� g�nderir
- Chat ID'yi loglara yazar

### 3. **Program.cs** (G�ncellendi)
- `AuthorizationService` dependency injection'a eklendi

### 4. **appsettings.json** & **appsettings.Development.json** (G�ncellendi)
- `TelegramBot:AuthorizedChatIds` ayar� eklendi

---

## ?? Kurulum ve Kullan�m

### 1. Chat ID'nizi Bulun

#### Y�ntem 1: Bot ile Konu�ma
1. Telegram'da botunuza `/start` g�nderin
2. Konsol loglar�nda chat ID'nizi g�receksiniz:
   ```
   ?? Yetkisiz eri�im denemesi - Chat ID: 123456789
   ```

#### Y�ntem 2: getUpdates API
1. Botunuza bir mesaj g�nderin
2. Taray�c�da �u URL'i a��n:
   ```
   https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
   ```
3. JSON yan�t�nda `"chat":{"id":123456789}` k�sm�n� bulun

### 2. Yetkili Chat ID'leri Ekleyin

#### Geli�tirme Ortam�
`appsettings.Development.json` dosyas�n� d�zenleyin:

```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "123456789,987654321,555666777"
  }
}
```

#### Production Ortam�
`appsettings.json` dosyas�n� d�zenleyin veya **Environment Variable** kullan�n:

```bash
export TelegramBot__AuthorizedChatIds="123456789,987654321"
```

**Veya Docker:**
```yaml
environment:
  - TelegramBot__AuthorizedChatIds=123456789,987654321
```

### 3. Formatlama Kurallar�

- **Virg�lle ay�r�n**: `"123456789,987654321,555666777"`
- **Bo�luk kullanmay�n** (veya otomatik temizlenir)
- **Negatif ID'ler desteklenir**: Grup/kanal chat ID'leri i�in
  - �rnek: `"-1001234567890,123456789"`

---

## ?? �zellikler

### ? G�venlik
- ?? Sadece yetkili chat ID'ler botu kullanabilir
- ?? Yetkisiz eri�im denemeleri loglan�r
- ?? Chat ID bilgisi yetkisiz kullan�c�ya g�sterilir (y�neticiye kolayl�k)

### ?? Loglama
- ?? Yetkili kullan�c� say�s� ba�lang��ta loglan�r
- ?? Her yetkisiz eri�im denemesi detayl� loglan�r
- ?? Ge�ersiz chat ID formatlar� uyar� verir

### ?? Dinamik Y�netim
- ?? Uygulama yeniden ba�latmadan config de�i�iklikleri (hot-reload)
- ?? �oklu chat ID deste�i
- ?? Hem bireysel hem grup chat ID'leri desteklenir

---

## ?? Test Etme

### 1. Yetkisiz Kullan�c� Testi

Yetkili olmayan bir Telegram hesab�ndan botunuza `/start` g�nderin.

**Beklenen Yan�t:**
```
?? YETK�S�Z ER���M

? Bu botu kullanma yetkiniz bulunmamaktad�r.

?? Chat ID: 123456789

?? Eri�im i�in sistem y�neticisi ile ileti�ime ge�iniz.
```

**Konsol Logu:**
```
?? Yetkisiz eri�im denemesi - Chat ID: 123456789
Unauthorized access denied for chat ID: 123456789
```

### 2. Yetkili Kullan�c� Testi

Yetkili bir hesaptan `/start` g�nderin.

**Beklenen Yan�t:**
Ana men� ve t�m komutlar normal �al��acak.

**Konsol Logu:**
```
Message: /start from 987654321
```

### 3. Ba�lang�� Logu

Uygulama ba�larken:
```
? Yetkili chat ID eklendi: 123456789
? Yetkili chat ID eklendi: 987654321
?? Toplam yetkili kullan�c� say�s�: 2
```

---

## ??? Sorun Giderme

### ? "Yetkili chat ID'leri yap�land�r�lmam��!"

**Neden:** `appsettings.json` dosyas�nda `AuthorizedChatIds` bo� veya yok.

**��z�m:**
```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "YOUR_CHAT_ID_HERE"
  }
}
```

### ? "Ge�ersiz chat ID format�"

**Neden:** Chat ID say� format�nda de�il.

**��z�m:** Chat ID'lerin sadece rakamlardan olu�tu�undan emin olun:
```json
"AuthorizedChatIds": "123456789"  // ? Do�ru
"AuthorizedChatIds": "abc123"      // ? Yanl��
```

### ? Hala yetkisiz g�r�n�yor

**Kontrol Listesi:**
1. ? Chat ID'yi do�ru kopyalad�n�z m�?
2. ? Virg�llerle do�ru ay�rd�n�z m�?
3. ? Uygulamay� yeniden ba�latt�n�z m�?
4. ? Do�ru `appsettings.json` dosyas�n� m� d�zenliyorsunuz?
   - Development: `appsettings.Development.json`
   - Production: `appsettings.json` veya env variable

---

## ?? �rnek Senaryolar

### Senaryo 1: Tek Kullan�c�
```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "123456789"
  }
}
```

### Senaryo 2: Birden Fazla Kullan�c�
```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "123456789,987654321,555666777"
  }
}
```

### Senaryo 3: Kullan�c� + Telegram Grubu
```json
{
  "TelegramBot": {
    "AuthorizedChatIds": "123456789,-1001234567890"
  }
}
```
*(Negatif ID'ler grup/kanal chat ID'leridir)*

### Senaryo 4: Environment Variable (Docker/Production)
```bash
docker run -e TelegramBot__AuthorizedChatIds="123456789,987654321" mybot:latest
```

---

## ?? G�venlik Notlar�

### ? Yap�lmas� Gerekenler
- ?? Chat ID'leri **gizli tutun** (public repo'larda payla�may�n)
- ?? Production'da **environment variable** kullan�n
- ?? Bot token'�n� **asla** kod i�inde saklamay�n
- ?? D�zenli olarak yetkisiz eri�im loglar�n� kontrol edin

### ? Yap�lmamas� Gerekenler
- ? Chat ID'leri GitHub'a **commit etmeyin**
- ? Bot token'�n� **appsettings.json**'da b�rakmay�n
- ? "Herkes i�in a��k" ayar yapmay�n

---

## ?? Kod Yap�s�

### AuthorizationService.cs
```csharp
public class AuthorizationService
{
    public bool IsAuthorized(long chatId)  // Ana kontrol metodu
    public int GetAuthorizedUserCount()    // �statistik
    public IReadOnlySet<long> GetAuthorizedChatIds()  // T�m yetkili ID'ler
}
```

### BotUpdateHandler.cs
```csharp
public async Task HandleUpdateAsync(...)
{
    // 1. Chat ID al
    long chatId = GetChatIdFromUpdate(update);
    
    // 2. Yetki kontrol�
    if (!_authorizationService.IsAuthorized(chatId))
    {
        await SendUnauthorizedMessage(...);
        return;
    }
    
    // 3. Normal i�lemlere devam et
    await HandleMessageAsync(...);
}
```

---

## ?? Deployment

### Docker Compose �rne�i
```yaml
version: '3.8'
services:
  telegram-bot:
    image: isyonetimi-telegram-bot:latest
    environment:
      - TELEGRAM_BOT_TOKEN=${BOT_TOKEN}
      - TelegramBot__AuthorizedChatIds=${AUTHORIZED_CHAT_IDS}
      - DB_CONNECTION_STRING=${DB_CONN}
    restart: unless-stopped
```

**.env dosyas�:**
```env
BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
AUTHORIZED_CHAT_IDS=123456789,987654321
DB_CONN=Server=...
```

---

## ?? G�ncellemeler ve Bak�m

### Yeni Kullan�c� Ekleme
1. Chat ID'yi ��renin (konsol loglar�ndan veya API'den)
2. `appsettings.json` dosyas�n� g�ncelleyin
3. Uygulamay� yeniden ba�lat�n (veya hot-reload bekleyin)

### Kullan�c� ��karma
1. Chat ID'yi listeden silin
2. Dosyay� kaydedin
3. Uygulama otomatik olarak yenileyecek

---

## ?? Destek

### Sorun mu ya��yorsunuz?

1. **Loglar� kontrol edin**: Konsol ��kt�lar�nda detayl� bilgi var
2. **Chat ID'yi do�rulay�n**: Yetkisiz eri�im mesaj�nda g�sterilir
3. **Yap�land�rmay� kontrol edin**: `appsettings.json` do�ru mu?

---

## ? Kurulum Tamamland�!

Art�k Telegram botunuz **g�venli bir �ekilde** sadece yetkili kullan�c�lar taraf�ndan kullan�labilir.

**Build Status:** ? Ba�ar�l�  
**Test Status:** ? Test bekliyor  
**Versiyon:** 1.0.0  
**Tarih:** {DateTime.Now:dd MMMM yyyy}

?? **G�venli kullan�mlar!**
